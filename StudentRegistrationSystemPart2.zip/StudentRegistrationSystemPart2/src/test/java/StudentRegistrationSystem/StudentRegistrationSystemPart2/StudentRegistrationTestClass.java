package StudentRegistrationSystem.StudentRegistrationSystemPart2;

import java.util.ArrayList;

import org.junit.Test;

import SoftwareEngineeringAssignment1.StudentRegistrationSystem.*;

import static org.junit.Assert.*;

public class StudentRegistrationTestClass {
	
	@Test
	public void StudentRegistrationTestClass(){
		
		ArrayList<String> BiologyStudents = new ArrayList<String>();
		
		BiologyStudents.add("JohnCorridon20");
		BiologyStudents.add("ShaunMahony20");
		BiologyStudents.add("PadraigCarroll21");
		BiologyStudents.add("BrendanDunne19");
		BiologyStudents.add("MichealReidy20");
		
		ArrayList<String> BiologyLecturers = new ArrayList<String>();
		
		BiologyLecturers.add("StephenWallace");
		BiologyLecturers.add("JohnBurns");
		
		Module Biology = new Module("Biology", "BI102", BiologyStudents, BiologyLecturers);
		
		ArrayList<String> ChemistryStudents = new ArrayList<String>();
		
		ChemistryStudents.add("ShaunMahony20");
		ChemistryStudents.add("PadraigCarroll21");
		ChemistryStudents.add("BrendanDunne19");
		
		ArrayList<String> ChemistryLecturers = new ArrayList<String>();
		
		ChemistryLecturers.add("MichaelLong");
		ChemistryLecturers.add("ElizabethEarly");
		
		Module Chemistry = new Module("Chemistry", "CH101", ChemistryStudents, ChemistryLecturers);
		
		ArrayList<String> PhysicsStudents = new ArrayList<String>();
		
		PhysicsStudents.add("JohnCorridon20");
		PhysicsStudents.add("ShaunMahony20");
		PhysicsStudents.add("PadraigCarroll21");
		BiologyStudents.add("BrendanDunne19");
		BiologyStudents.add("MichealReidy20");
		
		ArrayList<String> PhysicsLecturers = new ArrayList<String>();
		
		PhysicsLecturers.add("DavidRice");
		PhysicsLecturers.add("DermotHorgan");
		
		Module Physics = new Module("Physics", "PH103", PhysicsStudents, PhysicsLecturers);
		
		ArrayList<String> ASModules = new ArrayList<String>();
		
		ASModules.add("Biology");
		ASModules.add("Physics");
		
		ArrayList<String> GSModules = new ArrayList<String>();
		
		GSModules.add("Biology");
		GSModules.add("Physics");
		GSModules.add("Chemistry");
		
		//Issue with getting CourseProgramme to work due to Datetime even though Joda Datetime is included in Part1 projet and associated jar.
// 		CourseProgramme AgriculturalScience = new CourseProgramme("Agricultural Science", "AS", ASModules, null, null);
//		CourseProgramme GeneralScience = new CourseProgramme("General Science", "GS", GSModules, null, null);
		
		ArrayList<String> JCModules = new ArrayList<String>();
		
		JCModules.add("Biology");
		JCModules.add("Physics");
		
		ArrayList<String> JCModulesIDs = new ArrayList<String>();
		
		JCModulesIDs.add("BI102");
		JCModulesIDs.add("PH103");
		
		ArrayList<String> SMModules = new ArrayList<String>();
		
		SMModules.add("Biology");
		SMModules.add("Physics");
		SMModules.add("Chemistry");
		
		ArrayList<String> SMModulesIDs = new ArrayList<String>();
		
		SMModulesIDs.add("BI102");
		SMModulesIDs.add("PH103");
		SMModulesIDs.add("CH101");
		
		ArrayList<String> PCModules = new ArrayList<String>();
		
		PCModules.add("Biology");
		PCModules.add("Physics");
		PCModules.add("Chemistry");
		
		ArrayList<String> PCModulesIDs = new ArrayList<String>();
		
		PCModulesIDs.add("BI102");
		PCModulesIDs.add("PH103");
		PCModulesIDs.add("CH101");
		
		ArrayList<String> BDModules = new ArrayList<String>();
		
		BDModules.add("Biology");
		BDModules.add("Physics");
		BDModules.add("Chemistry");
		
		ArrayList<String> BDModulesIDs = new ArrayList<String>();
		
		BDModulesIDs.add("BI102");
		BDModulesIDs.add("PH103");
		BDModulesIDs.add("CH101");
			
		ArrayList<String> MRModules = new ArrayList<String>();
		
		MRModules.add("Biology");
		MRModules.add("Physics");
		
		ArrayList<String> MRModulesIDs = new ArrayList<String>();
		
		MRModulesIDs.add("BI102");
		MRModulesIDs.add("PH103");
		
		Student A = new Student("John", "Corridon", 20, null, 13567382, "JohnCorridon20", "Agricultural Science", "AS", JCModules, JCModulesIDs);
		Student B = new Student("Shaun", "Mahony", 20, null, 13546271, "ShaunMahony20", "General Science", "GS", SMModules, SMModulesIDs);
		Student C = new Student("Padraig", "Carroll", 21, null, 12343845, "PadraigCarroll21", "GeneralScience", "GS", PCModules, PCModulesIDs);
		Student D = new Student("Brendan", "Dunne", 19, null, 12357628, "BrendanDunne19", "General Science", "GS", BDModules, BDModulesIDs);
		Student E = new Student("Micheal", "Reidy", 20, null, 1345789, "MichealReidy20", "Agricultural Science", "AS", MRModules, MRModulesIDs);
		
		System.out.println(A.toString() + "\n" + B.toString() + "\n" + C.toString() + "\n" + D.toString() + "\n" + E.toString());
	}
}
