package SoftwareEngineeringAssignment1.StudentRegistrationSystem;

import static org.junit.Assert.*;

import org.junit.Test;

public class StudentTestUserName {

	@Test
	public void getUserNameTest() {
		
		Student Student = new Student("Micheal", "Reidy", 20, null, 0, null, null, null, null, null);
		String username = Student.getUserName();
		assertEquals("MichealReidy20", username);
	}
}
