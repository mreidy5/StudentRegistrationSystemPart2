package SoftwareEngineeringAssignment1.StudentRegistrationSystem;

import java.util.ArrayList;

import org.joda.time.*;;

public class CourseProgramme {

	private String CourseName;
	private String CourseCode;
	private ArrayList<String> Modules;
	private DateTime AcademicStartDate;
	private DateTime AcademicEndDate;
	
	
	//Constructor Method
	public CourseProgramme(String CourseName, String CourseCode, ArrayList<String> Modules, DateTime AcademicStartDate, DateTime AcademicEndDate)
	{
		this.CourseName = CourseName;
		this.CourseCode = CourseCode;
		this.Modules = Modules;
		this.AcademicStartDate = AcademicStartDate;
		this.AcademicEndDate = AcademicEndDate;
	}
	
	public String getCourseName() {
		return CourseName;
	}
	
	public void setCourseName(String CourseName) {
		this.CourseName = CourseName;
	}
	
	public String getCourseCode() {
		return CourseCode;
	}
	
	public void setCourseCode(String CourseCode) {
		this.CourseCode = CourseCode;
	}
	
	public ArrayList<String> getModules() {
		return Modules;
	}
	
	public void setModules(ArrayList<String> Modules) {
		this.Modules = Modules;
	}
	
	public DateTime AcademicStartDate() {
		return AcademicStartDate;
	}
	
	public void setAcademicStartDate(DateTime AcademicStartDate) {
		this.AcademicStartDate = AcademicStartDate;
	}
	
	public DateTime AcademicEndDate() {
		return AcademicEndDate;
	}
	
	public void setAcademicEndDate(DateTime AcademicEndDate) {
		this.AcademicEndDate = AcademicEndDate;
	}
}